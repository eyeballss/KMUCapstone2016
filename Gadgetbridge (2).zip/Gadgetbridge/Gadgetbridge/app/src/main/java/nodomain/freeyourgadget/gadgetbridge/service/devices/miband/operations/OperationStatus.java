package nodomain.freeyourgadget.gadgetbridge.service.devices.miband.operations;

public enum OperationStatus {
    INITIAL,
    STARTED,
    RUNNING,
    FINISHED
}
