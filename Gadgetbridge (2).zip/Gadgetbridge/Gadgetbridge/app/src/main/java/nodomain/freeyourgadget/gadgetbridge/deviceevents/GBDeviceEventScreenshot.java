package nodomain.freeyourgadget.gadgetbridge.deviceevents;

public class GBDeviceEventScreenshot extends GBDeviceEvent {
    public int width;
    public int height;
    public byte bpp;
    public byte[] clut;
    public byte[] data;
}
