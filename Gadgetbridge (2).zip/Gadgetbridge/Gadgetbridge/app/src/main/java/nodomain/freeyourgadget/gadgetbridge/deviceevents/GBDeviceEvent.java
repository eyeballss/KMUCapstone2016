package nodomain.freeyourgadget.gadgetbridge.deviceevents;


public abstract class GBDeviceEvent {

}

