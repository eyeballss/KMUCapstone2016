package nodomain.freeyourgadget.gadgetbridge.activities.charts;

public abstract class ChartsData {
}
