package nodomain.freeyourgadget.gadgetbridge.activities;

import android.os.Bundle;

import nodomain.freeyourgadget.gadgetbridge.R;

public class AndroidPairingActivity extends GBActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_android_pairing);
    }
}
