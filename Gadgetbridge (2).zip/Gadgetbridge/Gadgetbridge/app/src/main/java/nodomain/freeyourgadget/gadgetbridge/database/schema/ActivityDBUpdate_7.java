package nodomain.freeyourgadget.gadgetbridge.database.schema;

/**
 * Bugfix for users who installed 0.8.1 cleanly, i.e. without any previous
 * database. Perform Update script 6 again.
 */
public class ActivityDBUpdate_7 extends ActivityDBUpdate_6 {
}
