package nodomain.freeyourgadget.gadgetbridge.model;

public enum NotificationType {

    UNDEFINED,

    CHAT,
    EMAIL,
    FACEBOOK,
    SMS,
    TWITTER,
}
